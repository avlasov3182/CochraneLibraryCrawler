package org.cochrane.dbo;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class CochraneTopicDbo implements Comparable {

    private String url;
    private String name;
    private Set<CochraneReviewDbo> reviewList = new HashSet();

    public CochraneTopicDbo(String url, String name) {
        setUrl(url);
        setName(name);
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        name = name.replaceAll("&amp;", "&");
        this.name = name;
    }

    public Set<CochraneReviewDbo> getReviewList() {
        return reviewList;
    }

    public void setReviewList(Set<CochraneReviewDbo> reviewList) {
        this.reviewList = reviewList;
    }

    @Override
    public String toString() {
        return "CochraneTopicDbo{" +
                "Url='" + url + '\'' +
                ", Name='" + name + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CochraneTopicDbo)) return false;
        CochraneTopicDbo that = (CochraneTopicDbo) o;
        return Objects.equals(getUrl(), that.getUrl());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getUrl());
    }


    @Override
    public int compareTo(Object o) {
        if (!(o instanceof CochraneTopicDbo)) {
            return 0;
        }
        CochraneTopicDbo dbo = (CochraneTopicDbo) o;
        return this.getName().compareTo(dbo.name);
    }
}
