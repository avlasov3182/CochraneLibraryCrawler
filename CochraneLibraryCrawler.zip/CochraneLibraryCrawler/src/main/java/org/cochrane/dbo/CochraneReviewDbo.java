package org.cochrane.dbo;

public class CochraneReviewDbo {

    private String url;
    private CochraneTopicDbo topic;
    private String title;
    private String author;
    private String date;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public CochraneTopicDbo getTopic() {
        return topic;
    }

    public void setTopic(CochraneTopicDbo topic) {
        this.topic = topic;
    }

    @Override
    public String toString() {
        return url + "|" + topic.getName() + "|" + title + "|" + author + "|" + date + System.lineSeparator();
    }
}
