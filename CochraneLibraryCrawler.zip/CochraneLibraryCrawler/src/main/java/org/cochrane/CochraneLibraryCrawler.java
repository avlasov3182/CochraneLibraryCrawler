package org.cochrane;

import org.cochrane.dbo.CochraneReviewDbo;
import org.cochrane.dbo.CochraneTopicDbo;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class CochraneLibraryCrawler {

    public static String REPORT_FILE_NAME = "cochrane_reviews_" + System.currentTimeMillis() + ".txt";

    public static String TOPIC_URL_ATTR = "_scolarissearchresultsportlet_WAR_scolarissearchresults_facetCategory=Topics";
    public static String TOPIC_LIST_URL_DEFAULT = "https://www.cochranelibrary.com/cdsr/reviews/topics";

    private String topicListUrl = TOPIC_LIST_URL_DEFAULT;
    private Set<CochraneTopicDbo> cochraneTopics = new TreeSet<CochraneTopicDbo>();

    private Path reportFile = Paths.get(REPORT_FILE_NAME);

    public CochraneLibraryCrawler(String url) {
        if (url != null) {
            topicListUrl = url;
        } else {
            System.out.println("Error: Please set up URL for list of topics and try again");
        }
        try {
            Files.createFile(reportFile);
        } catch (IOException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        ;
    }

    public void start() {
        System.out.println("Started");
        System.out.println("Designated URL: " + topicListUrl);
        System.out.println("Report file location " + reportFile.toFile().getAbsolutePath());
        buildTopicList();
        System.out.println("List of topics completed");
        for (CochraneTopicDbo topic : cochraneTopics) {
            buildReviewList(topic);
            System.out.println("List of reviews completed");
            appendToReport(topic);
        }
        System.out.println("Report completed");
        System.out.println("Finished");
    }

    private void buildReviewList(CochraneTopicDbo topic) {
        try {
            Set<CochraneReviewDbo> reviews = new HashSet<CochraneReviewDbo>();
            boolean isLastPage = false;
            int curPage = 1;
            String currentPageUrl = topic.getUrl();
            while (!isLastPage) {
                Document document = Jsoup.connect(currentPageUrl + "&cur=" + curPage).get();
                Elements pageSearchResultList = document.select("div.search-results-item");
                System.out.println(topic.getName() + ": page " + curPage + " has " + pageSearchResultList.size() + " reviews");
                for (Element pageSearchResult : pageSearchResultList) {
                    CochraneReviewDbo review = new CochraneReviewDbo();
                    review.setTitle(pageSearchResult.select("h3.result-title").select("a[href]").first().text());
                    review.setUrl(pageSearchResult.select("a[href]").attr("abs:href"));
                    review.setAuthor(pageSearchResult.select("div.search-result-authors").first().text());
                    review.setDate(pageSearchResult.select("div.search-result-date").first().text());
                    review.setTopic(topic);
                    reviews.add(review);
                }
                if (pageSearchResultList == null || pageSearchResultList.size() == 0) {
                    isLastPage = true;
                } else {
                    curPage++;
                }
            }
            topic.setReviewList(reviews);
        } catch (Exception e) {
            System.err.println("For '" + topic.toString() + "': " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void buildTopicList() {
        try {
            Document document = Jsoup.connect(topicListUrl).get();
            Elements linksOnPage = document.select("a[href]");

            for (Element href : linksOnPage) {
                String url = href.attr("href");
                if (url.contains(TOPIC_URL_ATTR)) {
                    String name = href.child(0).html();
                    cochraneTopics.add(new CochraneTopicDbo(url, name));
                }
            }
        } catch (IOException e) {
            System.err.println("For '" + topicListUrl + "': " + e.getMessage());
            e.printStackTrace();
        }

    }

    private void appendToReport(CochraneTopicDbo topic) {
        try {
            for (CochraneReviewDbo review : topic.getReviewList())
                Files.writeString(reportFile, review.toString() + System.lineSeparator(), StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        System.out.println("Appended to the report");
    }

    public static void main(String[] args) {
        String url = TOPIC_LIST_URL_DEFAULT;
        if(args != null && args.length >= 1) {
          url = args[0];
        }
        new CochraneLibraryCrawler(url).start();
    }

}
